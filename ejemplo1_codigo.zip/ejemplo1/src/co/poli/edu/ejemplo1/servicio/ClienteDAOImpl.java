package co.poli.edu.ejemplo1.servicio;

import co.poli.edu.ejemplo1.modelo.Cliente;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * 
 */
public class ClienteDAOImpl implements GestorElementoDAO {

    private Connection connection = Singleton.getInstance().getConnection();

    @Override
    public String createElemento(Object elemento) {
    	Cliente cliente = (Cliente) elemento;
        String sql = "INSERT INTO cliente (idcliente, nombre) VALUES (?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            //pstmt.setString(1, cliente.getId());
        	pstmt.setInt(1, Integer.parseInt(cliente.getId()));
            pstmt.setString(2, cliente.getNombre());
            pstmt.executeUpdate();
            return "Cliente " + cliente.getId() + " creado exitosamente";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Error al crear el cliente";
        }
    }

    @Override
    public List<Object> listAllElementos() {
    	List<Object> clientes = new ArrayList<>();
        String sql = "SELECT * FROM cliente";

        try (PreparedStatement pstmt = connection.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
            	 String id = String.valueOf(rs.getInt("idcliente"));
                 String nombre = rs.getString("nombre");
                 Cliente cliente = new Cliente(id, nombre); // Inicializa el objeto Cliente con argumentos
                 clientes.add(cliente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clientes;
    }

    @Override
    public Object readElemento(String id) {
    	String sql = "SELECT * FROM cliente WHERE idcliente = ?";
        Cliente cliente = null;

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, Integer.parseInt(id));
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                cliente = new Cliente(String.valueOf(rs.getInt("idcliente")), rs.getString("nombre")); // Inicializa el objeto Cliente con argumentos
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cliente;
    }

    @Override
    public String updateElemento(String id, Object elemento) {
    	Cliente cliente = (Cliente) elemento;
        String sql = "UPDATE cliente SET nombre = ? WHERE idcliente = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, cliente.getNombre());
            pstmt.setInt(2, Integer.parseInt(id));
            pstmt.executeUpdate();
            return "Cliente actualizado exitosamente";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Error al actualizar el cliente";
        }
    }

    @Override
    public Object deleteElemento(String id) {
    	String sql = "DELETE FROM cliente WHERE idcliente = ?";
        Cliente cliente = (Cliente) readElemento(id);

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, Integer.parseInt(id));
            pstmt.executeUpdate();
            return cliente;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

}